import { BiSolidStar } from 'react-icons/bi'
import { BsArrowDown, BsArrowUp } from 'react-icons/bs'
import { TbListDetails } from 'react-icons/tb'

import { getTexts } from '@/Helpers/Language/getTexts.helper'

import { AllDigimons } from '@/GameData/Digimons'

import { useProfileStore } from '@/Stores/Profile.store'
import { useSceneStore } from '@/Stores/Scene.store'
import { useDigiviceStore } from '@/Stores/Digivice.store'

import { Button } from '@/Components/System/Button'
import { Text } from '@/Components/System/Text'
import { Portrait } from '@/Components/System/Portrait'

import { PartnerDetails } from '@/Components/App/PartnerDetails'
import { EncyclopediaHeader } from '@/Components/App/EncyclopediaHeader'

import './PartnersList.style.scss'

export const PartnersList = () => {
  const { profile, setProfile } = useProfileStore((state) => state)
  const { digivice, setDigivice } = useDigiviceStore((state) => state)
  const { scene } = useSceneStore((state) => state)

  if (!!digivice?.currentDetails) {
    return <PartnerDetails />
  }

  const allPartners = Object.values(profile?.partnerDigimons!).map(
    (partner) => ({
      ...partner,
      baseDigimon: AllDigimons[partner.baseDigimon]
    })
  )

  const partners = {
    inParty: allPartners.filter(
      (partner) => !!profile?.party.includes(partner.id)
    ),

    others: allPartners.filter(
      (partner) => !profile?.party.includes(partner.id)
    )
  }

  const removeFromParty = (id: number) => {
    setProfile({
      ...profile!,
      party: profile!.party.filter((partner) => partner !== id) ?? []
    })
  }

  const addToParty = (id: number) => {
    setProfile({
      ...profile!,
      party: [...profile!.party, id]
    })
  }

  const seeDetails = (id: number) => {
    setDigivice({
      ...digivice!,
      currentDetails: id
    })
  }

  return (
    <div className="partners-list">
      <EncyclopediaHeader />

      {Object.keys(partners).map((category) => (
        <div
          className="partners-list-category"
          key={`partners-list-partners-${category}`}
        >
          <Text>
            {getTexts(`ENCYCLOPEDIA_CATEGORY_${category.toLocaleUpperCase()}`)}
          </Text>

          <div className="partners-list-list">
            {!!partners[category].length ? (
              partners[category].map((partner) => (
                <div
                  className="partners-list-partner"
                  key={`partners-list-partner-${partner.id}`}
                >
                  <aside className="partner-avatar">
                    <Portrait
                      alt={partner.name || partner.baseDigimon.name}
                      src={`/${partner.baseDigimon.portrait}.webp`}
                    />
                  </aside>

                  <header className="partner-name">
                    <Text>{partner?.name || partner?.baseDigimon?.name}</Text>

                    {partner?.name && <Text>{partner?.baseDigimon?.name}</Text>}
                  </header>

                  <aside>
                    {!!partner.isFavorite && (
                      <Text>
                        <BiSolidStar />
                      </Text>
                    )}
                  </aside>

                  <footer>
                    <Button
                      disabled={!!scene}
                      onClick={() => seeDetails(partner.id)}
                    >
                      <TbListDetails />
                    </Button>

                    {category === 'inParty' && (
                      <Button
                        disabled={!!scene || profile!.party.length < 2}
                        onClick={() => removeFromParty(partner.id)}
                      >
                        <BsArrowDown />
                      </Button>
                    )}

                    {category === 'others' && (
                      <Button
                        disabled={!!scene || profile!.party.length > 2}
                        onClick={() => addToParty(partner.id)}
                      >
                        <BsArrowUp />
                      </Button>
                    )}
                  </footer>
                </div>
              ))
            ) : (
              <Text>{getTexts('ENCYCLOPEDIA_NO_OTHERS')}</Text>
            )}
          </div>
        </div>
      ))}
    </div>
  )
}
