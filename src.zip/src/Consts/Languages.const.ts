export const LANGUAGES = ['en']
